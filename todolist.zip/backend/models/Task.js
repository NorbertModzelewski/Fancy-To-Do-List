const mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  title: String,
  priority: Number,
  deadline: Date,
  description: String,
  status: { type: String, default: 'to-do' }
});

module.exports = mongoose.model('Task', TaskSchema);
const mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  title: String,
  priority: Number,
  deadline: String,
  description: String,
  status: { type: String, default: "to-do" }
});

module.exports = mongoose.model("Task", TaskSchema);