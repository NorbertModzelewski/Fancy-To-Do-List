function redirectToHome() {
    window.location.href = "index.html";
}
function toggleForm(formType) {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');

    if (formType === 'login') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
    }
}

toggleForm('login');

const email = document.getElementById('signup-email');
        const username = document.getElementById('signup-username');
        const password = document.getElementById('signup-password');
        const formLogin = document.getElementById('login-form');
        const formSignup = document.getElementById('signup-form');
        const errorElementLogin = document.getElementById('error-login');
        const successElementLogin = document.getElementById('success-login');
        const errorElementSignup = document.getElementById('error-signup');
        const successElementSignup = document.getElementById('success-signup');

        formLogin.addEventListener('submit', (e) => {
            e.preventDefault();
            errorElementLogin.innerText = '';
            successElementLogin.style.display = 'none';
            let messages = [];

            const loginUsername = document.getElementById('login-username').value;
            const loginPassword = document.getElementById('login-password').value;

            if (loginUsername === '' || loginUsername == null) {
                messages.push('Invalid username.');
            }

            if (loginPassword === '' || loginPassword == null) {
                messages.push('Password is required.');
            }

            if (messages.length > 0) {
                errorElementLogin.innerText = messages.join('\n');
                return;
            }

            successElementLogin.style.display = 'block';

            setTimeout(() => {
                formLogin.submit();
            }, 1500);
        });

        formSignup.addEventListener('submit', (e) => {
            e.preventDefault();
            errorElementSignup.innerText = '';
            successElementSignup.style.display = 'none';
            let messages = [];

            if (!email.value.match(/^[A-Za-z\._\-0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)) {
                messages.push('Invalid email address.');
            }

            if (username.value === '' || username.value == null) {
                messages.push('Username is required.');
            }

            if (username.value.length > 20) {
                messages.push('Username must contain 20 characters maximum.');
            }

            const passwordValue = password.value;
            const passwordRequirements = [
                { regex: /.{6,20}/, message: 'Password must contain 6-20 characters.' },
                { regex: /[a-z]/, message: 'Password must contain at least one small letter' },
                { regex: /[A-Z]/, message: 'Password must contain at least one grand letter' },
                { regex: /[0-9]/, message: 'Password must contain at least one digit.' },
                { regex: /[!@#$%^&*(),.?":{}|<>]/, message: 'Password must contain at least one special character.' }
            ];

            passwordRequirements.forEach(req => {
                if (!req.regex.test(passwordValue)) {
                    messages.push(req.message);
                }
            });

            if (messages.length > 0) {
                errorElementSignup.innerText = messages.join('\n');
                return;
            }

            successElementSignup.style.display = 'block';

            setTimeout(() => {
                formSignup.submit();
            }, 1500);
        });